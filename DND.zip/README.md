It is a pomodoro app.

build with: python build_mac_app.py

<img width="337" alt="image" src="https://github.com/user-attachments/assets/72521543-58d5-4bfd-9f15-78d3e6d27a43">
<img width="490" alt="image" src="https://github.com/user-attachments/assets/37efb09d-024f-4433-b5ca-029d77d7cbec">
